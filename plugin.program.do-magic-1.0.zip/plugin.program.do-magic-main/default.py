# -*- coding: utf-8 -*-
# Manage Kodi Favourites program add-on for Kodi 17.6+.
# Lets you see and manage your Kodi favourites, to organize them.
# In other words, this is an add-on to edit your
# favourites.xml file.
#
# --------------------------------------------------------------------
# M-Borsch 2026-02-28: Version 1.0
# - Initial Release
# --------------------------------------------------------------------
#
# ====================================================================
import re
import sys
import json
import traceback
import xbmc
import xbmcgui
import os
import shutil
import xbmcvfs
import urllib.request

try:
    # Python 2.x
    from HTMLParser import HTMLParser
    PARSER = HTMLParser()
    DECODE_STRING = lambda val: val.decode('utf-8')
except ImportError as e:
    # Python 3.4+ (see https://stackoverflow.com/a/2360639)
    import html
    PARSER = html
    DECODE_STRING = lambda val: val # Pass-through.

import xbmc, xbmcgui, xbmcplugin, xbmcvfs
from xbmcaddon import Addon

DEBUG = '0'
DEBUG2 = '1'
# Flag to put up the Under Construction Popup
DEBUG3 = '0'
SETTINGS_PATH = 'special://addons/pvr.stalker/resources/settings.xml'

ADDON = Addon()
PLUGIN_ID = int(sys.argv[1])
PLUGIN_URL = sys.argv[0]

#===================================================================================

def execFunction():

    dialog = xbmcgui.Dialog()
    # Parameters: yesno(heading, message, yeslabel='Yes', nolabel='No')
    # labels to "OK" and "Cancel"
    choice = dialog.yesno("Run " + magicFunction, "Do you want to proceed?\n\n[I]Use the [B]Configure...[/B] option to select a different Function[/I]", yeslabel="Proceed...", nolabel="Cancel")

    if choice:
        # User clicked OK (Yes)
        if magicFunction == ADDON.getLocalizedString(30007):
            execDownloadFunction()
        elif magicFunction == ADDON.getLocalizedString(30012):
            execHashFunction() 
        elif magicFunction == ADDON.getLocalizedString(30017):
            execBackgroudFunction()
        elif magicFunction == ADDON.getLocalizedString(30026):
            addMBKodiFileSources()
        elif magicFunction == ADDON.getLocalizedString(30029):
            execConfBackgroudFunction() 
        #elif magicFunction == ADDON.getLocalizedString(30008):
            #execStalkerTweakFunction() 
        else:
            # Display an error dialog if the operation fails
            dialog = xbmcgui.Dialog()
            dialog.ok("File Operation Error", f"[COLOR red]do-magic: [/COLOR]Operation Denied.\n\nNot Authorized to Run Function")

def isValidFile(filename):
    # List of allowed image extensions
    allowed = ['.jpg', '.jpeg', '.png']
    ext = os.path.splitext(filename)[1].lower()
    return ext in allowed

def execConfBackgroudFunction():

    if magicConfBackgroundFlag:

        # Get the base add-on path (encoded)
        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

        # Define path to a resource file
        resource_file = os.path.join(addon_path, 'resources', magicConfBackground)

        # Check if file exists
        if isValidFile(resource_file) and xbmcvfs.exists(resource_file):
            # Process the file
            updateConfluenceBackground(resource_file)
        else:
            # Display an error dialog if the operation fails
            dialog = xbmcgui.Dialog()
            dialog.ok("File Operation Error", f"[COLOR red]do-magic: [/COLOR]Error: Invalid Filename \n\n" +  resource_file)

    else:
         # Check if file exists
        if isValidFile(magicConfCusBackground) and xbmcvfs.exists(magicConfCusBackground):
            # Process the file
            updateConfluenceBackground(magicConfCusBackground)
        else:
            # Display an error dialog if the operation fails
            dialog = xbmcgui.Dialog()
            dialog.ok("File Operation Error", f"[COLOR red]do-magic: [/COLOR]Error: Invalid Filename \n\n" +  magicConfCusBackground)


def addMBKodiFileSources():

        userdata_pathDIR = xbmcvfs.translatePath('special://userdata/')
        filename = 'sources.xml'
        # debugfilename = 'debug.xml'

         # Get the base add-on path (encoded)
        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

        # Define path to a resource file
        replacement_file_path = os.path.join(addon_path, 'resources', 'MB-KODI-sources.xml')

         # Check if file exists
        if xbmcvfs.exists(replacement_file_path):
            
            # Process the file
            # File paths (ensure these paths are correct for your Kodi setup)
            target_file_path = os.path.join(userdata_pathDIR, filename)
            #debug_file_path  = os.path.join(userdata_pathDIR, debugfilename)
            string_to_replace = '</files>'
            
            # Read the content that will be used for replacement
            with open(replacement_file_path, 'r') as f:
                new_content = f.read()
            
            # Read the target file
            with open(target_file_path, 'r') as f:
                target_data = f.read()
            
            # Replace the specific string with the new content
            updated_data = target_data.replace(string_to_replace, new_content)
            
            # Save the changes back to the target file
            with open(target_file_path, 'w') as f:
               f.write(updated_data)

            # Save the changes back to the debug target file
            #with open(debug_file_path, 'w') as f:
            #    f.write(updated_data)
                
            # Display a confirmation dialog (requires xbmcgui)
            dialog = xbmcgui.Dialog()
            line2 = "[COLOR blue]MB-KODI-ADDONS: [/COLOR][COLOR green]MB-KODI-ADDONS File Source Successfully Added[/COLOR]\n\n[COLOR red]IMPORTANT: These File Sources will show up next time you restart KODI...[/COLOR]"
        
            dialog.ok("[COLOR red]do-magic: [/COLOR]File Sources Function", line2)
            #xbmc.executebuiltin('LoadProfile(%s)' % xbmc.getInfoLabel('System.ProfileName'))

        else:
            # Display an error dialog if the operation fails
            dialog = xbmcgui.Dialog()
            dialog.ok("File Operation Error", f"[COLOR red]do-magic: [/COLOR]Error: Invalid Filename \n\n" +  replacement_file_path)

def updateConfluenceBackground(targetfilename):

        # Define the absolute path to your new background image
        new_background_path = targetfilename
        
        # Enable the custom background setting in Confluence
        # In Confluence, the toggle is typically controlled by 'Skin.HasSetting(CustomBackground)'
        xbmc.executebuiltin('Skin.SetBool(CustomBackground, true)')
        
        # Set the background image path
        # Confluence uses the setting 'CustomBackgroundPath' to store the image location
        xbmc.executebuiltin(f'Skin.SetString(CustomBackgroundPath, "{new_background_path}")')

def updateKodiBackground(targetfilename):
    
        userdata_pathDIR = xbmcvfs.translatePath('special://userdata/')
    
        ADDONS_PATH = xbmcvfs.translatePath('special://home/')
        BACKGROUND_PATH = os.path.join(ADDONS_PATH, "addons/skin.confluence/backgrounds/")
    
        filename = 'SKINDEFAULT.jpg'
    
        # setup target location
        save_path = BACKGROUND_PATH + filename
    
        # Copy the background file to target location using Kodi's built-in SMB handling
        if xbmcvfs.copy(targetfilename, save_path):
            xbmc.log("Background: File downloaded successfully", xbmc.LOGINFO)
        else:
            xbmc.log("Background: Failed to download file", xbmc.LOGERROR)
    
        # Optional: Inform the user
        xbmc.executebuiltin('Notification(Background, Updated, 2000)')
            
        # Display a confirmation dialog (requires xbmcgui)
        dialog = xbmcgui.Dialog()
        line2 = "[COLOR blue]Set Background To: [/COLOR][COLOR green]" + targetfilename + "[/COLOR]\n\n" + "Reloading Kodi profile. This may take several seconds..."
    
        dialog.ok("[COLOR red]do-magic: [/COLOR]Background Function", line2)
        xbmc.executebuiltin('LoadProfile(%s)' % xbmc.getInfoLabel('System.ProfileName'))

def execBackgroudFunction():

    if magicBackgroundFlag:

        # Get the base add-on path (encoded)
        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

        # Define path to a resource file
        resource_file = os.path.join(addon_path, 'resources', magicBackground)

        # Check if file exists
        if isValidFile(resource_file) and xbmcvfs.exists(resource_file):
            # Process the file
            updateCofluenceBackground(resource_file)
        else:
            # Display an error dialog if the operation fails
            dialog = xbmcgui.Dialog()
            dialog.ok("File Operation Error", f"[COLOR red]do-magic: [/COLOR]Error: Invalid Filename \n\n" +  resource_file)

    else:
         # Check if file exists
        if isValidFile(magicCusBackground) and xbmcvfs.exists(magicCusBackground):
            # Process the file
            updateKiodiBackground(magicCusBackground)
        else:
            # Display an error dialog if the operation fails
            dialog = xbmcgui.Dialog()
            dialog.ok("File Operation Error", f"[COLOR red]do-magic: [/COLOR]Error: Invalid Filename \n\n" +  magicCusBackground)

def execHashFunction():

    # Generate a salt and hash password
    hashed = xbmc.getCacheThumbName( magicHash ).split('.', 1)[0]
    
    # Display a confirmation dialog (requires xbmcgui)
    dialog = xbmcgui.Dialog()
    line2 = "[COLOR blue]Hashing:[/COLOR] " + magicHash + " [COLOR blue]\nTo:[/COLOR] [COLOR green]" + hashed + "[/COLOR]"

    dialog.ok("[COLOR red]do-magic: [/COLOR]HASH Function", line2)


def execDownloadFunction():

    if magicDownloadFlag:
        srcFile = ADDON.getLocalizedString(30035) + 'd/' + magicUrl
    else:
        srcFile = magicUrl
    
    # Display a confirmation dialog (requires xbmcgui)
    dialog = xbmcgui.Dialog()
    line2 = "[COLOR blue]From:[/COLOR] " + srcFile + "\n[COLOR green]To:[/COLOR] " + magicDir + magicName

    dialog.ok("[COLOR red]do-magic: [/COLOR]Downloading file", line2)

    # Check if file exists
    if xbmcvfs.exists(srcFile):
        # Process the file
        # Start the download
        download_with_progress(srcFile, magicName)
    else:
        # Display an error dialog if the operation fails
        dialog = xbmcgui.Dialog()
        dialog.ok("File Operation Error", f"[COLOR red]do-magic: [/COLOR]Error: Invalid Source Filename \n\n" +  srcFile)

def download_with_progress(url, dest_name):
    
    dp = xbmcgui.DialogProgress()
    dp.create('Downloading', 'Starting download...\n\nPlease Wait...may take time depending on file size')
    
    # Use xbmcvfs to handle paths across different OSs
    save_path = xbmcvfs.translatePath(os.path.join(magicDir, dest_name))

    def reporthook(count, block_size, total_size):
        if total_size > 0:
            percent = int(count * block_size * 100 / total_size)
            dp.update(percent, f"Downloaded {percent}% of file")
        
        if dp.iscanceled():
            urllib.request.urlcleanup()
            raise Exception("Download Cancelled")

    # Copy file using Kodi's built-in SMB handling
    if xbmcvfs.copy(url, save_path):
        xbmc.log("File downloaded successfully", xbmc.LOGINFO)
         # Optional: Inform the user
        xbmc.executebuiltin('Notification(Downloader, ' + dest_name + ' dowloaded, 2000)')
    else:
        xbmc.log("Failed to download file", xbmc.LOGERROR)
    #try:
    #    urllib.request.urlretrieve(url, save_path, reporthook)
    #    dp.close()
    #except Exception as e:
    #    dp.close()
    #    print(f"Error: {e}")
        
def execStalkerTweekFunction():
    xbmc.executebuiltin('Notification(Stalker, Tweeked, 2000)')   

def execStalkerFunction():

    # --- Configuration Variables ---
    # Type of browse dialog: 1 = ShowAndGetFile
    browse_type = 1
    # Dialog heading
    heading = 'Select the settings.xml file'
    # The starting path. Use "" to list local drives and network shares
    # or specify a default path like 'special://home/addons/'
    default_path = 'special://home' 
    # File mask for readable files (e.g., text, xml, log files). Use '|' to separate extensions.
    file_mask = 'settings.xml' 
    # Enable multiple file selection (optional)
    enable_multiple = False
    
    # --- Show the browse dialog ---
    dialog = xbmcgui.Dialog()
    selected_file_path = dialog.browse(
        browse_type,
        heading,
        '',  # shares parameter: "" for local/network sources, "files" for file sources
        file_mask,
        enableMultiple=enable_multiple,
        defaultt=default_path # default path to start browsing from
    )

    # Does the selected file include "settings.xml"
    if "settings.xml" in selected_file_path:
    
        # --- Process the result ---
        if selected_file_path:
            xbmc.log(f"[COLOR red]do-magic: [/COLOR]Selected file path: {selected_file_path}", xbmc.LOGINFO)
            # You can now use xbmcvfs to read the file content
            # Example (requires importing xbmcvfs):
            # import xbmcvfs
            # with xbmcvfs.File(selected_file_path, 'r') as f:
            #     content = f.read()
            #     xbmc.log(f"File content snippet: {content[:100]}", xbmc.LOGINFO)
    
            # Define source and destination paths using xbmc.translatePath()
            # 'special://home/' is a common built-in path in Kodi that points to the userdata folder
            src = xbmcvfs.translatePath(selected_file_path)
            dst = xbmcvfs.translatePath(SETTINGS_PATH)
            
            # Add error handling using a try-except block
            try:
                # shutil.copyfile(src, dst)
                xbmcvfs.copy(src, dst)
                # Display a confirmation dialog (requires xbmcgui)
                dialog = xbmcgui.Dialog()
                dialog.ok("File Operation", "[COLOR red]do-magic: [/COLOR]settings.xml successfully copied!\n\nYou must relaunch the impacted Addon to view the change")
            except IOError as e:
                # Display an error dialog if the operation fails
                dialog = xbmcgui.Dialog()
                dialog.ok("File Operation Error", f"[COLOR red]do-magic: [/COLOR]Error copying settings.xml file: {e}")
        
        else:
            xbmc.log("[COLOR red]do-magic: [/COLOR]File selection cancelled by user.", xbmc.LOGINFO)
    else:
        # Display an error dialog if the operation fails
        dialog = xbmcgui.Dialog()
        dialog.ok("File Operation Error", f"[COLOR red]do-magic: [/COLOR]Invalid Filename: Please select 'settings.xml'")

def getRawWindowProperty(prop):
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    return window.getProperty(prop)

def setRawWindowProperty(prop, data):
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    window.setProperty(prop, data)

def clearWindowProperty(prop):
    window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    window.clearProperty(prop)

# Debugging helper. Logs a LOGNERROR-level message.
def xbmcLog(*args):
    xbmc.log('[COLOR yellow]Manage Kodi Favourites > [/COLOR]' + ' '.join((var if isinstance(var, str) else repr(var)) for var in args), level=xbmc.LOGERROR)
#===================================================================================

### Entry point ###

if '/exit_only' in PLUGIN_URL:
    xbmc.executebuiltin('Action(Back)')
    # Alternative action, going to the Home screen.
    #xbmc.executebuiltin('ActivateWindow(home)') # ID taken from https://kodi.wiki/view/Window_IDs

elif '/configure' in PLUGIN_URL:
    # Call up the configuration panel.
    # Activate the Settings window
    xbmc.executebuiltin('Addon.OpenSettings(do-magic)')

elif '/fmanager' in PLUGIN_URL:
    # Call up the File Manager.
    xbmc.executebuiltin("ActivateWindow(FileManager)")

elif '/function' in PLUGIN_URL:   
    magicPassword = '' if not ADDON.getSetting('magicPWD') else ADDON.getSetting('magicPWD')
    magicFunction = '' if not ADDON.getSetting('magicFUNCTION') else ADDON.getSetting('magicFUNCTION')

    magicDownloadFlag = '' if not ADDON.getSettingBool('magicDNLDFLG') else ADDON.getSettingBool('magicDNLDFLG')    
    magicName = '' if not ADDON.getSetting('magicNAME') else ADDON.getSetting('magicNAME')
    magicUrl = '' if not ADDON.getSetting('magicURL') else ADDON.getSetting('magicURL')
    magicDir = '' if not ADDON.getSetting('magicDIR') else ADDON.getSetting('magicDIR')
    magicHash = '' if not ADDON.getSetting('magicHASH') else ADDON.getSetting('magicHASH')
    
    magicBackgroundFlag = '' if not ADDON.getSettingBool('magicBKGNDFLG') else ADDON.getSettingBool('magicBKGNDFLG')
    magicConfBackgroundFlag = '' if not ADDON.getSettingBool('magicCONFBKGNDFLG') else ADDON.getSettingBool('magicCONFBKGNDFLG')
    
    magicCusBackground = '' if not ADDON.getSetting('magicCUSBKGNDFILE') else ADDON.getSetting('magicCUSBKGNDFILE')
    magicConfCusBackground = '' if not ADDON.getSetting('magicCONFCUSBKGNDFILE') else ADDON.getSetting('magicCONFCUSBKGNDFILE')

    magicBackground = '' if not ADDON.getSetting('magicBKGNDFILE') else ADDON.getSetting('magicBKGNDFILE')
    magicConfBackground = '' if not ADDON.getSetting('magicCONFBKGNDFILE') else ADDON.getSetting('magicCONFBKGNDFILE')
    
    if  xbmc.getCacheThumbName( magicPassword ).split('.', 1)[0] == ADDON.getLocalizedString(30005):
        execFunction()   
    else:
        # Display an error dialog if the operation fails
        dialog = xbmcgui.Dialog()
        dialog.ok("File Operation Error", f"[COLOR blue]do-magic: [/COLOR][COLOR blue]Operation Denied.\n\nInvalid PWD[/COLOR]")

else:
    # Create the menu items.
    xbmcplugin.setContent(PLUGIN_ID, 'files')
    configureItem = xbmcgui.ListItem('[B]Configure... (Enter PWD/Function in Settings)[/B]')
    configureItem.setArt({'thumb': 'DefaultFolderBack.png'})
    configureItem.setInfo('video', {'plot': 'Configure the default actions in Settings panel.'})
    execute_function = xbmcgui.ListItem('[COLOR lightgreen][B]   Execute Function [/COLOR](Advanced! - This may modify your Kodi install)[/B]')
    execute_function.setArt({'thumb': 'DefaultAddonsUpdates.png'})
    execute_function.setInfo('video', {'plot': 'Advanced - Modify certain Kodi Functionality'})
    file_manager = xbmcgui.ListItem('[COLOR red][B]   Launch File Manager...[/B][/COLOR]')
    file_manager.setArt({'thumb': 'DefaultAddonsUpdates.png'})
    file_manager.setInfo('video', {'plot': 'Launch File Manager...'})
    exitItem = xbmcgui.ListItem('[B]Exit[/B]')
    exitItem.setArt({'thumb': 'DefaultFolderBack.png'})
    exitItem.setInfo('video', {'plot': 'Exit the add-on (same as pressing Back), without saving your changes.'})

    xbmcplugin.addDirectoryItems(
        PLUGIN_ID,
        (
            # PLUGIN_URL already ends with a slash, so just append the route to it.
            (PLUGIN_URL + 'configure', configureItem, False),
            (PLUGIN_URL + 'function', execute_function, False),
            (PLUGIN_URL + 'fmanager', file_manager, False),
            (PLUGIN_URL + 'exit_only', exitItem, False)
        )
    )
    xbmcplugin.endOfDirectory(PLUGIN_ID)
